import UIKit

class Note {
    var noteId: Int
    var name: String
    var text: String
    var isFavourite: Bool
    var creationDate: Date
    var deletionDate: Date
    var isDeleted: Bool
    init(noteId: Int, name: String, text: String = "") {
        self.noteId = noteId
        self.name = name
        self.text = text
        self.isFavourite = false
        self.creationDate = Date()
        self.deletionDate = Date()
        self.isDeleted = false
    }
}

class NoteDataManager {
    
    var notesArray: Array <Note>
    
    init(notesArray: Array <Note> = []) {
        self.notesArray = notesArray
    }
    
    func create(name: String, text: String = "") -> Int {
        let newNote = Note(noteId: self.notesArray.count + 1, name: name, text: text)
        if (self.searchByName(name: name) != nil){
            print("There already exists Note with such name.")
            return -1
        }
        while (self.checkPresence(noteToSearchName: newNote.name, noteToSearchId: newNote.noteId) == true) {
            newNote.noteId += 1
        }
        self.notesArray.append(newNote)
        print("New Note was created.")
        return 0
    }
    
    func read(name: String){
        let noteToRead = self.searchByName(name: name)
        if (noteToRead != nil) {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd.MM.yyyy"
            print(formatter.string(from: noteToRead!.creationDate))
            print(noteToRead?.name as Any)
            print(noteToRead?.text as Any)
        }else {
            print("This Note was not found!")
        }
    }
    
    func update(nameToUpdate: String, newText: String = "") {
        let noteToUpdate = self.searchByName(name: nameToUpdate)
        if (noteToUpdate != nil){
            noteToUpdate?.text = newText
            print("Note was updated.")
        } else {
            print("Note was not found.")
        }
    }
    
    func delete(nameToDelete: String){
        let noteToDelete = self.searchByName(name: nameToDelete)
        if (noteToDelete != nil) {
            noteToDelete?.deletionDate = Date()
            noteToDelete?.isDeleted = true
            print("Note was deleted.")
        } else {
            print("Note was not found.")
        }
    }
    
    func restore(nameToRestore: String) {
        let noteToRestore = self.searchByName(name: nameToRestore)
        if (noteToRestore != nil) {
            noteToRestore?.isDeleted = false
        }else{
            print("Note was not found.")
        }
    }
    
    func checkPresence(noteToSearchName: String = "", noteToSearchId: Int = 0) -> Bool{
        for note in self.notesArray{
            if ((note.noteId == noteToSearchId || note.name == noteToSearchName) && note.isDeleted == false){
                return true
            }
        }
        return false
    }
    
    func searchByName(name: String) -> Note? {
        for note in self.notesArray {
            if (note.name == name){
                return note
            }
        }
        return nil
    }
    
    func makeFavorite(id: Int){
        for note in self.notesArray{
            if (note.noteId == id) {
                note.isFavourite = true
                print("Note made favorite.")
            }
        }
    }
    
    func makeNotFavorite(id: Int){
        for note in self.notesArray{
            if (note.noteId == id) {
                note.isFavourite = false
                print("Note made not favorite.")
            }
        }
    }
    
    func filter() {
        print("Filtered Notes:")
        for note in self.notesArray {
            if (note.isFavourite == true && note.isDeleted == false){
                print(note.name)
            }
        }
    }
    
    func sort(){
        self.notesArray.sort {
            $0.creationDate > $1.creationDate
        }
    }
}


var note1 = Note(noteId: 1, name: "note1", text: "text for note 1.")
var note2 = Note(noteId: 2, name: "note2", text: "text for note 2.")
note2.creationDate = Date().addingTimeInterval(-100000.0)
var arr: Array <Note> = [note1, note2]
var noteDataManager = NoteDataManager(notesArray: arr)
noteDataManager.read(name: "nOtE")
noteDataManager.read(name: "note2")
noteDataManager.create(name: "note2")
noteDataManager.create(name: "note3", text: "text for note 3.")
print(noteDataManager.checkPresence(noteToSearchName: "note3"))
noteDataManager.makeFavorite(id: 3)
noteDataManager.makeFavorite(id: 1)
noteDataManager.filter()
noteDataManager.makeNotFavorite(id: 1)
noteDataManager.filter()
noteDataManager.delete(nameToDelete: "note3")
print(noteDataManager.checkPresence(noteToSearchName: "note3"))
noteDataManager.restore(nameToRestore: "note3")
print(noteDataManager.checkPresence(noteToSearchName: "note3"))
noteDataManager.sort()
for note in noteDataManager.notesArray {
    print(note.name)
}
